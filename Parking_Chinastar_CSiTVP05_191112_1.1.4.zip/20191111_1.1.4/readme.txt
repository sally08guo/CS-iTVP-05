1.开机报文增加解析字段
  复位状态寄存器-ResetStatusRegister
  异常标识-ExceptionIdentification
  复位位置-ResetPosition
  绝对无车门限-NoVehicleThreshold
  绝对有车门限-HaveVehicleThreshold
  检测门限等级-VehicleDetectionThresholdLevel
  采样时间间隔-TimelySampleInterval
2.平台下发命令config时，ipadress输入格式变为：xxx.xxx.xxx.xxx 字符串形式输入
3.ipadress支持输入-1 65535等数字
4.上报数据排序
